<?php
 
// no direct access
defined( '_JEXEC' ) or die( 'Restricted access' );
 
// Include the syndicate functions only once
require_once __DIR__ . '/helper.php';

require( JModuleHelper::getLayoutPath( 'mod_helion_pojedyncza_ksiazka' ) );
?>