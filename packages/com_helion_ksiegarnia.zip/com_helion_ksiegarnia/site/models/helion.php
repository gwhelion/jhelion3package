<?php
// No direct access to this file
defined('_JEXEC') or die('Restricted access');
 
// import Joomla modelitem library
jimport('joomla.application.component.modelitem');
 
/**
 * HelloWorld Model
 */
class HelionModelHelion extends JModelItem
{
	/**
	 * @var string msg
	 */
	protected $msg;
 
    
}

?>