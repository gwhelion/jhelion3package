<?php
// No direct access to this file
defined('_JEXEC') or die('Restricted access');
 
// import Joomla controller library
//jimport('joomla.application.component.controller');
 
/**
 * Helion Component Controller
 */
class HelionController extends JControllerLegacy
{
    
}

?>