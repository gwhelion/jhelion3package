<?php

class modHelionKategorieHelper
{

}
?>
